OCSPanel
=========
Simple and lightweight panel for Reseller SSH based on Webmin API, 100% free.

Features
--------
* **Sistem Deposit** : ReSeller cukup Deposit Saldo ke Admin, sudah bisa create Account SSH sendiri.
* **Remote Webmin** : cukup 1 panel bisa dipakai untuk banyak Remote VPS.

Requirements
------------

##### Hosting
* PHP versi 5.3.4 keatas.
* MySQL versi 5.0.0 keatas.

##### VPS
* Webmin
* Perl XML::Parser Module (biasa otomatis terinstall bersama webmin)

Installation
------------
* Debian: http://infosshanaksolo.blogspot.com/2017/05/install-ssh-reseller-ocs-panel-pada-vps.html
